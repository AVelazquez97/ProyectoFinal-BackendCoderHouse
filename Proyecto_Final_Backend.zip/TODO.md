+ Mejorar el código de las funciones que tienen demasiado complejidad (refactorizar)

+ Escribir middleware para manejo de errores, como por ejemplo para los id's incorrectos

+ Desarrollar una capa de frontend