# Backend e-commerce project in NodeJs

# Tecnologies

- NodeJS 16.15.xx
- NPM 8.13.xx

# Development

## Install
```
npm install 
```
or
```
npm i
```

## Start server

```
npm start
```
or
```
node server.js
```

## Testing

+ With rest-client
