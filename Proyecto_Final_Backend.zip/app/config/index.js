import dotenv from 'dotenv';

dotenv.config();

const APP_PORT = process.env.APP_PORT;

export { APP_PORT };
